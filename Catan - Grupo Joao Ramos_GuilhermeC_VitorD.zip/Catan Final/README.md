# Trabalho 2 de INTRODU��O A COMPUTA��O - Jogo Settlers of Catan

## Trabalho feito por:
	* Jo�o Ramos a21807286
	* Guilherme Carvalho a21803633
	* Vitor Daniel a21804362

## Descri��o da resolu��o:

	* Print est�tico do mapa para ser usado como guia aos jogadores
	* Diversas fun��es colocadas num ficheiro header para gerir os recursos e lan�amento de dados
	* Pergunta onde colocar a primeira aldeia com uma fun��o nomeada "input" que ultiliza um scanf
	* Uma s�rie de ifs que conferem o numero dos dados do jogador e lhe d� recursos dependendo da posi��o da aldeia do jogador
	* Recursos do jogadores s�o guardados em variaveis
	* Segue um fluxograma em PDF que serviou para orientar a cria��o do trabalho por mais que nem todas as fun��es l� presentes tenham sido implementadas
	* A cada nova aldeia um ponto � acidionado ao jogador, com 4 pontos o jogo termina.

## Manual de ultilizador:
	* Para jogar, seleciona uma casa para montar sua aldeia, o N, S, E, W s�o North, South, East e West. L, I, B, G, D s�o:
Lumber, Iron, Brick, Grain e Desert
	* Ao conseguir um Lumber podes contruir uma nova aldeia, a cada aleia que construas ganhas um ponto, com quatro pontos, vences o jogo
	* (obs : escolha ent�o uma casa com Lumber no inicio) (N�o foi possiv�l implementar todas as fun�oes do jogo, tornando assim alguns dos recursos basicamente in�teis.

## Conclus�es e Materia Aprendida:
	* No inicio tentei ultilizar um array para gerenciar o mapa, mas acabou por ser mesmo s� uma fun��o com prints, para guardar informa��es do jogador, uma lista com os paremtros do jogador (recursos) era a ideia inicial mas apos diversos erros a solu��o foi ultilizar uma vari�vel.
## Refernecias: 
	* Pesquisas no google e consulta a forums como stackoverflow
